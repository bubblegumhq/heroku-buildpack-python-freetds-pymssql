#define FREETDS_SYSCONFDIR "/usr/local/etc"
